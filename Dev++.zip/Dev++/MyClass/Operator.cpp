#include "Operator.h"
#include "..\Model\coins.h"
#include "..\Model\Wallet.h"

namespace MyClass
{

	using namespace Model;
	using namespace std;

	bool Operator::ValidationAddWallet(Wallet model, vector<Wallet> DataList)
	{
		Wallet d;
		Coins d2;
		for (int i = 0; i < DataList.size(); i++)
		{
			if (DataList[i].IsDeleted == true)
				continue;

			if (DataList[i].getId() == model.getId())
				throw 104;
		}

		if (Regex(model.getPass()))
		{
			return true;
		}
	}
	bool Operator::transfer(Wallet* From, Wallet* To, Model::Coins coin)
	{
		Wallet wl = *From;
		Wallet twl = *To;

		wl.reduceCoine(coin.GetType(), coin.GetSize(), coin.GetCount());
		twl.addCoine(coin.GetType(), coin.GetSize(), coin.GetCount());

		*From = wl;
		*To = twl;
		return true;
	}
	bool Operator::Regex(string input)
	{

		const std::regex r(R"~(^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$)~");
		std::cmatch m;

		bool acc = regex_match(input, r);
		return acc;
	}
	string Operator::TypeToString(Coins coin) {
		string out;
		switch (coin.GetType())
		{
		case gold:
			out = "Gold";
			break;

		case silver:
			out = "Silver";
			break;
		}
		return out;

	}
	string Operator::SizeToString(Coins coin) {
		string out;

		switch (coin.GetSize())
		{

		case full:
			out = "Full";
			break;

		case half:
			out = "Half";
			break;

		case quarter:
			out = "Quarter";
			break;
		}
		return out;

	}
	void Operator::Error(int ErrorCode) {
		system("CLS");
		cout << "Error " << ErrorCode << " : ";
		string Error;
		switch (ErrorCode)
		{
		case 100:
			Error = "";
			break;
		case 101:
			Error = "Inventory is not enough";
			break;
		case 102:
			Error = "";
			break;
		case 103:
			Error = "Coins with this specification are not available in the wallet";
			break;
		case 104:
			Error = "Duplicate Wallet Id";
			break;
		case 105:
			Error = "Short WalltId ID";
			break;
		case 106:
			Error = "Wallet not found";
			break;
		case 107:
			Error = "Destination wallet not found";
			break;
		case 108:
			Error = "Invalid Password";
			break;
		case 109:
			Error = "Short WalltId ID";
			break;
		case 110:
			Error = "";
			break;
		case 111:
			Error = "Invalid Count";
			break;
		}
		if (Error == "") Error = "Unknown error";
		cout << Error;
	}
	vector<string> Operator::split(string str, char seperator)
	{
		int currIndex = 0, i = 0;
		int startIndex = 0, endIndex = 0;
		vector<string> Sl;
		while (i <= str.length())
		{
			if (str[i] == seperator || i == str.length())
			{
				endIndex = i;
				string subStr = "";
				subStr.append(str, startIndex, endIndex - startIndex);
				Sl.push_back(subStr);
				currIndex += 1;
				startIndex = endIndex + 1;
			}
			i++;
		}
		return Sl;
	}
	vector<Wallet> Operator::Deserilaize(string Data) {

		vector<Wallet> Result;
		vector<string> step1 = split(Data, '|');
		for (int i = 0; i < step1.size(); i++)
		{
			Wallet wallet;
			string SD = step1[i];
			vector<string> step2 = split(SD, ',');
			wallet.setWallet(step2[1], step2[0]);
			string Coi = step2[2];

			if (Coi != "null") {
				vector<string> step3 = split(Coi, '/');

				for (int j = 0; j < step3.size(); j++)
				{
					string Coi2 = step3[j];
					vector<string> step4 = split(Coi2, '+');
					wallet.addCoine(stoi(step4[0]), stoi(step4[1]), stoi(step4[2]));
				}
			}


			Result.push_back(wallet);
		}
		return Result;
	}
	string Operator::serilaize(vector<Wallet> Data) {
		string Result = "";
		for (int i = 0; i < Data.size(); i++)
		{
			Wallet wallet = Data[i];
			if (i != 0)Result += "|";

			string th = wallet.getId() + "," + wallet.getPass() + ",";
			vector<Coins> CL = wallet.getCoins();
			if (CL.size() == 0)th += "null";
			for (int j = 0; j < CL.size(); j++)
			{
				Coins coin = CL[j];
				string ch = to_string(coin.GetType()) + "+" + to_string(coin.GetSize()) + "+" + to_string(coin.GetCount());
				if (j != 0)th += "/";
				th += ch;
			}
			Result += th;
		}
		return Result;
	}

}

