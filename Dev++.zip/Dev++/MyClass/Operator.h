#ifndef OPERATOR_H
#define OPERATOR_H


#include "..\Model\coins.h"
#include "..\Model\Wallet.h"

#include <vector>
#include <string>
#include <regex>


namespace MyClass
{

    using namespace Model;
    using namespace std;

    class Operator
    {

    public:
    	Wallet f;
        static bool ValidationAddWallet(Wallet model, vector<Wallet> DataList);
        static bool transfer(Wallet* From, Wallet* To, Model::Coins coin);
        static bool Regex(string input);
        static string TypeToString(Coins input);
        static string SizeToString(Coins input);
        static vector<Wallet> Deserilaize(string Data);
        static string serilaize(vector<Wallet> Data);
        static vector<string> split(string str, char seperator);
        static void Error(int ErrorCode);

    };
}
#endif
