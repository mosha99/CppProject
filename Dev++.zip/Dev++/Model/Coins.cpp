#include "Coins.h"

namespace Model
{
    Coins::Coins()
    {
        IsDeleted = false;
    }

    void Coins::SetCoin(int _Count, int _Type, int _Size)
    {
        this->Count = _Count;
        this->Size = _Size;
        this->Type = _Type;

    }

    int Coins::ChangeInventory(int ChangeValue)
    {
        if ((this->Count + ChangeValue) < 0)
            throw 101;
        this->Count += ChangeValue;
        return this->Count;
    }



    int Coins::GetCount()
    {
        return this->Count;
    }

    int Coins::GetType()
    {
        return this->Type;
    }

    int Coins::GetSize()
    {
        return this->Size;
    }


}
