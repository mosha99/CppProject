

#include "Wallet.h"
#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include "coins.h"
#include "..\MyClass\Operator.h"

using namespace std;
using namespace MyClass;

namespace Model
{
    double costGold = 100;
    double costSilver = 50;

    string Wallet::getId()
    {
        return WalletId;
    }
    void Wallet::setWallet(string pass, string walId)
    {
        if (!Operator::Regex(pass)) throw 108;
        if (!(walId.length() == 8)) throw 109;

        WalletId = walId;
        Password = pass;
    }
    string Wallet::getPass()
    {
        return Password;
    }
    Wallet::Wallet()
    {
        IsDeleted = false;
    }

    void Wallet::RemoveCoine(int Type, int Size, int Count)
    {

        bool Exist = false;
        int index;
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].GetSize() == Size && coins[i].IsDeleted != true)
            {
                coins[i].IsDeleted = true;
                Exist = true;
            }
        }

        if (!Exist)
            throw 103;
    }

    void Wallet::addCoine(int Type, int Size, int Count)
    {
        bool Exist = false;
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].GetSize() == Size && coins[i].IsDeleted != true)
            {
                Exist = true;
                increaseCoine(Type, Size, Count);
            }
        }

        if (!Exist) {
            Coins coin;
            coin.SetCoin(Count, Type, Size);
            coins.push_back(coin);
        }
       
    }

    void Wallet::increaseCoine(int Type, int Size, int Count)
    {
        Coins selectedCoin;
        Count = abs(Count);
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].GetSize() == Size && coins[i].IsDeleted != true)
            {
                coins[i].ChangeInventory(Count);
                break;
            }
        }
    }

    void Wallet::reduceCoine(int Type, int Size, int Count)
    {
        Coins selectedCoin;
        Count = abs(Count);
        Count = Count * -1;
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].GetSize() == Size && coins[i].IsDeleted != true)
            {
                coins[i].ChangeInventory(Count);
                return;
            }
        }
        throw 106;
    }

    vector<Coins> Wallet::getCoins()
    {
        return coins;
    }

    vector<Coins> Wallet::getCoins(int Type)
    {
        vector<Coins> selectedCoin;
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].IsDeleted != true)
                selectedCoin.push_back(coins[i]);
        }
        return selectedCoin;
    }

    Coins Wallet::getCoins(int Type, int Size)
    {
        vector<Coins> selectedCoin;
        for (int i = 0; i < coins.size(); i++)
        {
            if (coins[i].GetType() == Type && coins[i].GetSize() == Size && coins[i].IsDeleted != true)
                selectedCoin.push_back(coins[i]);
        }

        if (selectedCoin.size() > 1)
        {
            throw 100;
        }

        return selectedCoin[0];
    }

    double Wallet::getBalance()
    {
        double mojodi = 0;

        for (int i = 0; i < coins.size(); i++)
        {

            if (coins[i].IsDeleted == true)
                continue;

            double value = 1;

            Coins coin = coins[i];

            switch (coin.GetType())
            {

            case gold:
                value = value * 1;
                break;

            case silver:
                value = value * costSilver / costGold;
                break;
            }

            switch (coin.GetSize())
            {

            case full:
                value = value * 1;
                break;

            case half:
                value = value * 0.5;
                break;

            case quarter:
                value = value * 0.25;
                break;
            }

            value = value * coin.GetCount();

            value = value * costGold;

            mojodi += value;
        }
        return mojodi;
    }

}
