#ifndef COINS_H
#define COINS_H

namespace Model
{
	class Coins
	{
		 int Count, Size, Type;

	public:
		bool IsDeleted;
		void SetCoin(int, int, int);
		int GetCount();
		int GetType();
		int GetSize();
		int ChangeInventory(int);


		Coins();
	};
	enum CoinType
	{
		gold,
		silver,
	};

	enum CoinSize
	{
		full,
		half,
		quarter,
	};


}
#endif
