#ifndef WALLET_H
#define WALLET_H

#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include "coins.h"

//#include "..\MyClass\Operator.h"

using namespace std;

namespace Model
{
	class Wallet
	{
	private:
		string Password;
		vector<Coins> coins;
		string WalletId;

	public:

		bool IsDeleted;
		vector<Coins> getCoins();
		vector<Coins> getCoins(int);
		Coins getCoins(int, int);
		void setWallet(string, string);
		string getId();
		string getPass();
		double getBalance();
		void addCoine(int, int, int);
		void RemoveCoine(int, int, int);
		void increaseCoine(int, int, int);
		void reduceCoine(int, int, int);

		Wallet();
	};
}

#endif
