#include <iostream>

#include <iostream>
#include <vector>
#include <string>

#include <math.h> 
#include "Model\Coins.h"
#include "Model\Wallet.h"
#include "MyClass\Operator.h"

#include <regex>
#include<conio.h>
#include <thread>
#include <Windows.h>

#include <fstream>

using namespace std;
using namespace Model;
using namespace MyClass;

int FirstMenu();
void Welcome();
void AddWallet();
int  ViewWalletsMenue();
void ViewWallets(int);
int  ManageCoinesMenue();
void ManageCoines(int selected);
vector<Wallet> WalletList;




int main(int argc, char const* argv[])
{


string text;
fstream file;
file.open("DataBase.txt", ios::out | ios::in);
file >> text;
file.close();

if (text.length() > 17)WalletList = Operator::Deserilaize(text);
try
{
	Welcome();
	while (true)
	{
		int select = FirstMenu();
		if (select == 1) AddWallet();
		if (select == 2) ViewWallets(ViewWalletsMenue());
		if (select == 3) ManageCoines(ManageCoinesMenue());
		if (select == 0) throw 0;
	}
}
catch (int ErrorCode)
{
	if (ErrorCode != 0)
		Operator::Error(ErrorCode);
}
string d = Operator::serilaize(WalletList);
std::ofstream ofs("DataBase.txt", std::ios::out | std::ios::trunc);
ofs << d;
ofs.close();
system("CLS");
cout << "Save Succes";
	return 0;
}

void Welcome() {
	string h = "Hello";
	string w = "Welcome to digital wallet software";
	string p = "Please enter to continue ...";

	for (int i = 0; i < h.length(); i++)
	{
		this_thread::sleep_for(chrono::milliseconds(100));
		cout << h[i];
	}

	this_thread::sleep_for(chrono::milliseconds(1000));
	for (int i = 0; i < w.length(); i++)
	{
		if (i == 0)cout << endl;
		this_thread::sleep_for(chrono::milliseconds(75));
		cout << w[i];
	}
	this_thread::sleep_for(chrono::milliseconds(1000));
	for (int i = 0; i < p.length(); i++)
	{
		if (i == 0)cout << endl;
		this_thread::sleep_for(chrono::milliseconds(50));
		cout << p[i];
	}
	_getch();
	return;
}
int FirstMenu() {
	system("CLS");
	cout << endl << " 1 ) Add  Wallet ";
	cout << endl << "\n 2 ) View Wallets ";
	cout << endl << "\n 3 ) Manage Coines ";
	cout << endl << "\n 0 ) Save And Exit \n";
	char input = _getch();
	if (input <= '3' && input >= '0')
	{
		int a = input - 48;
		return a;
	}
	FirstMenu();
}
void AddWallet() {

	while (true)
	{
		system("CLS");
		try
		{
			Wallet wl;
			for (int i = 0; i < 50; i++)cout << "*";
			cout << '\n';
			cout << '\n' << "- ID must be numeric and length 8 and unique";
			cout << '\n';
			cout << '\n' << "- Password must be more than 8 digits and have uppercase and lowercase letters and special characters";
			cout << '\n';
			cout << '\n' << "- Exit with enter 0";
			cout << '\n' << '\n';
			for (int i = 0; i < 50; i++)cout << "*";
			cout << '\n' << '\n';
			cout << "Enter Id for Wallet : ";
			string Id;
			cin >> Id;
			if (Id == "") return;
			cout << "Enter  Passwosd for Wallet : ";
			string Passwosd;
			cin >> Passwosd;
			if (Passwosd == "0") return;

			wl.setWallet(Passwosd, Id);

			for (int i = 0; i < WalletList.size(); i++)
			{
				if (WalletList[i].getId() == wl.getId())
					throw 104;
			}
			WalletList.push_back(wl);

			system("CLS");
			cout << "\n\n Task completed ";

		}
		catch (int ErrorCode)
		{
			Operator::Error(ErrorCode);
		}

		cout << "\n\n  Are you continuing ? (y/n)";
		char h = _getch();
		if (tolower(h) == 'n') break;
	}
}
int ViewWalletsMenue() {
	system("CLS");

	cout << endl << " 1 ) View Wallet By Id ";
	cout << endl << "\n 2 ) View All Wallets ";
	cout << endl << "\n 0 ) Exit \n";
	char input = _getch();
	if (input == '0') return -1;
	if (input <= '2' && input >= '0')
	{
		int a = input - 48;
		return a;
	}
	ViewWalletsMenue();
}
Wallet FindWallet(string id) {

	for (int i = 0; i < WalletList.size(); i++)
	{
		if (WalletList[i].getId() == id) return WalletList[i];
	}
	throw 106;
}
void ViewWallets(int selected)
{
	system("CLS");

	if (selected == -1) return;
	vector<Wallet> result;
	if (selected == 1) {
		while (true)
		{
			try
			{
				cout << "Enter Wallet Id (Exit By 0): ";
				string id;// = cin.get();
				cin >> id;
				if (id == "0") return;
				result.push_back(FindWallet(id));
				break;
			}
			catch (int ErrorCode)
			{
				system("CLS");
				cout << "Wallet Not Find \n";


			}
		}
	}
	else
	{
		result = WalletList;
	}



	for (int i = 0; i < 50; i++)cout << "*";
	cout << "\n";
	for (int i = 0; i < result.size(); i++)
	{
		cout << "\n Wallet Id : " << result[i].getId();
		cout << "\n Wallet Password : ********** ";
		cout << "\n Wallet Balance : " << result[i].getBalance();

		int Ccount = 0;
		vector<Coins> AllCoine = result[i].getCoins();
		for (int j = 0; j < AllCoine.size(); j++)
		{
			Coins select = AllCoine[j];
			Ccount += select.GetCount();
		}

		cout << "\n Wallet Coines Count : " << Ccount;
		cout << "\n Wallet Coines : \n {\n";

		for (int j = 0; j < AllCoine.size(); j++)
		{
			Coins select = AllCoine[j];
			if (select.GetCount() == 0)continue;
			cout << "\n\t Type:" << Operator::TypeToString(select) << " ;\t Size:" << Operator::SizeToString(select) << " ;\t Count:" << select.GetCount();
		}
		cout << "\n\n }\n\n";
		for (int i = 0; i < 50; i++)cout << "*";
	}

	cout << "\n Please enter to continue ...";
	//cin.get();
	_getch();

}
int ManageCoinesMenue() {
	system("CLS");

	cout << endl << " 1 ) Add Coin to Wallet ";
	cout << endl << "\n 2 ) transfer Coin";
	cout << endl << "\n 0 ) Exit \n";

	char input = _getch();

	if (input <= '2' && input >= '0')
	{
		int a = input - 48;
		return a;
	}
	ViewWalletsMenue();
}
void AddCoin() {
	while (true)
	{
		try
		{
			system("CLS");

			for (int i = 0; i < 50; i++)cout << "*";
			cout << '\n';
			cout << '\n' << "- Exit with enter 0";
			cout << '\n' << '\n';
			for (int i = 0; i < 50; i++)cout << "*";


			cout << "\n Enter Target Wallet Id : ";
			string id;// = cin.get();
			cin >> id;
			if (id == "0")return;
			int Type, Size, count;
			cout << "\n Enter Type Coine : ";
			cout << "\n " << gold + 1 << " ) Gold ";
			cout << "\n " << silver + 1 << " ) Silver \n";

			while (true)
			{
				char input = _getch();
				if (input == '0')return;
				if (input <= '2' && input >= '0')
				{
					Type = input - 49;
					cout << " " << Type + 1;
					break;
				}
			}

			cout << "\n Enter Size Coine : ";

			cout << "\n " << full + 1 << " ) Full ";
			cout << "\n " << half + 1 << " ) Half ";
			cout << "\n " << quarter + 1 << " ) Quarter \n";

			while (true)
			{
				char input2 = _getch();
				if (input2 == '0')return;

				if (input2 <= '3' && input2 >= '0')
				{
					Size = input2 - 49;
					cout << " " << Size + 1;
					break;
				}
			}

			cout << "\n Enter Coine Count : ";

			//count = cin.get();
			cin >> count;
			if (count < 1) throw 111;
			int index = -1;

			for (int i = 0; i < WalletList.size(); i++)
			{
				if (WalletList[i].getId() == id) {
					index = i;
					break;
				}
			}
			if (index == -1)	throw 106;

			WalletList[index].addCoine(Type, Size, count);

			system("CLS");
			cout << "\n\n Task completed";
		}
		catch (int ErrorCode)
		{
			Operator::Error(ErrorCode);
		}

		cout << "\n\n Are you continuing ? (y/n)";
		char h = _getch();
		if (tolower(h) == 'n') break;
	}

	//cin.get();	cin.get();
}
void TransferCoin() {

	while (true)
	{
		try
		{
			system("CLS");

			for (int i = 0; i < 50; i++)cout << "*";
			cout << '\n';
			cout << '\n' << "- Selected coins must be in the wallet of origin";
			cout << '\n';
			cout << '\n' << "- Exit with enter 0";
			cout << '\n' << '\n';
			for (int i = 0; i < 50; i++)cout << "*";

			cout << "\n  From Wallet Id : ";
			string From;// = cin.get();
			cin >> From;
			if (From == "0") return;
			cout << "\n  To Wallet Id : ";
			string To;// = cin.get();
			cin >> To;
			if (To == "0") return;


			int Type, Size, count;
			cout << "\n Enter Type Coine : ";
			cout << "\n " << gold + 1 << " ) Gold ";
			cout << "\n " << silver + 1 << " ) Silver \n";

			while (true)
			{
				char input = _getch();
				if (input == '0')return;

				if (input <= '2' && input >= '0')
				{
					Type = input - 49;
					cout << " " << Type + 1;
					break;
				}
			}

			cout << "\n Enter Size Coine : ";

			cout << "\n " << full + 1 << " ) Full ";
			cout << "\n " << half + 1 << " ) Half ";
			cout << "\n " << quarter + 1 << " ) Quarter \n";

			while (true)
			{
				char input2 = _getch();
				if (input2 == '0')return;

				if (input2 <= '3' && input2 >= '0')
				{
					Size = input2 - 49;
					cout << " " << Size + 1;
					break;
				}
			}

			cout << "\n Enter Coine Count : ";

			//count = cin.get();
			cin >> count;
			if (count < 1) throw 111;

			int Findex = -1;

			for (int i = 0; i < WalletList.size(); i++)
			{
				if (WalletList[i].getId() == From) {
					Findex = i;
					break;
				}
			}
			if (Findex == -1)	throw 106;

			int index = -1;

			for (int i = 0; i < WalletList.size(); i++)
			{
				if (WalletList[i].getId() == To) {
					index = i;
					break;
				}
			}
			if (index == -1)	throw 106;


			Coins coin;
			coin.SetCoin(count, Type, Size);
			Operator::transfer(&WalletList[Findex], &WalletList[index], coin);

			system("CLS");
			cout << "\n\n Task completed";
		}
		catch (int ErrorCode)
		{
			Operator::Error(ErrorCode);
		}

		cout << "\n\n Are you continuing ? (y/n)";
		char h = _getch();
		if (tolower(h) == 'n') break;
	}

}
void ManageCoines(int selected)
{
	try
	{
		if (selected == 1) AddCoin();
		if (selected == 2) TransferCoin();
		if (selected == 0) return;
	}
	catch (int ErroCode)
	{
		cout << ErroCode;
	}


}


